from PIL import Image

img = Image.open('./a.jpg').convert('L')
img = img.resize((180, 160))
img.save('resized_180x160_v2.png')

width, height = img.size
pixels = list(img.getdata())

with open('input_pixels.txt', 'w') as f:
    f.write(f"{width}\n")
    f.write(f"{height}\n")
    for pixel in pixels:
        f.write(f"{pixel}\n")

print("image saved!")