from PIL import Image
import numpy as np
import sys

INPUT_FILE  = "output_pixels.txt"
OUTPUT_FILE = "output_Sharp.png"

WIDTH  = 180
HEIGHT = 160

with open(INPUT_FILE, "r") as f:
    pixels = [int(line.strip()) for line in f if line.strip() != ""]

if len(pixels) != WIDTH * HEIGHT:
    print(f"Warning: got {len(pixels)} pixels, expected {WIDTH*HEIGHT}. Will try to build a partial image.")
    height = len(pixels) // WIDTH
    if height == 0:
        raise ValueError("Not enough pixels to build even one row.")
    img_array = np.array(pixels[:height*WIDTH], dtype=np.uint8).reshape((height, WIDTH))
else:
    img_array = np.array(pixels, dtype=np.uint8).reshape((HEIGHT, WIDTH))

img = Image.fromarray(img_array, mode="L")
img.save(OUTPUT_FILE)
print("Saved", OUTPUT_FILE)